package com.example;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.Entity.Admin;


@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminTest {

    @Test
    public void testAdminFields() {
        Admin admin = new Admin();
        admin.setAdmin_id(1);
        admin.setUsername("testUser");
        admin.setPassword("testPass");
        admin.setHostel("testHostel");

        assertEquals(1, admin.getAdmin_id());
        assertEquals("testUser", admin.getUsername());
        assertEquals("testPass", admin.getPassword());
        assertEquals("testHostel", admin.getHostel());
    }
}