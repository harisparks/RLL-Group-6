package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.time.LocalTime;

import com.example.Entity.CleanRequest;
import com.example.Entity.Worker;
import com.example.Entity.Student;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CleanRequestTest {

    @Test
    public void testCleanRequestCreation() {
        // Create a Student instance for testing
        Student student = new Student();
        

        // Create a Worker instance for testing
        Worker worker = new Worker();
        worker.setWorker_id(1L);

        // Create a CleanRequest instance
        CleanRequest cleanRequest = new CleanRequest();
        cleanRequest.setRequest_id(1L);
        
        cleanRequest.setCleanTime(LocalTime.of(10, 0));
        cleanRequest.setFeedback_status(false);
        cleanRequest.setStudent(student);
        cleanRequest.setWorker(worker);
        cleanRequest.setReq_status(true);

        // Perform assertions to test the CleanRequest instance
        assertEquals(1L, cleanRequest.getRequest_id());
       assertEquals(LocalTime.of(10, 0), cleanRequest.getCleanTime());
        assertFalse(cleanRequest.isFeedback_status());
        assertEquals(student, cleanRequest.getStudent());
        assertEquals(worker, cleanRequest.getWorker());
        assertTrue(cleanRequest.isReq_status());
    }
}
