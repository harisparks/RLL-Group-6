package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.ArrayList;
import java.util.List;
import com.example.Entity.CleanRequest;
import com.example.Entity.Worker;


@RunWith(SpringRunner.class)
@SpringBootTest
public class WorkerTest {

    @Test
    public void testWorkerCleanRequestMapping() {
        // Create a Worker instance for testing
        Worker worker = new Worker();
        worker.setWorker_id(1L);
        worker.setName("John Doe");
        worker.setFloor(2);
        worker.setHostel("A");

        // Create CleanRequest instances for testing
        CleanRequest request1 = new CleanRequest();
        CleanRequest request2 = new CleanRequest();

        // Create a list of CleanRequest
        List<CleanRequest> cleanRequests = new ArrayList<>();
        cleanRequests.add(request1);
        cleanRequests.add(request2);

        // Set the list of clean requests in the worker
        worker.setCleanRequest(cleanRequests);

        // Perform assertions to test the worker instance
        assertEquals(1L, worker.getWorker_id());
        assertEquals("John Doe", worker.getName());
        assertEquals(2, worker.getFloor());
        assertEquals("A", worker.getHostel());
        assertEquals(cleanRequests, worker.getCleanRequest());
    }
}
