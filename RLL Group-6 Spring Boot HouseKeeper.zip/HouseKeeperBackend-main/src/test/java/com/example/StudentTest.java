package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.Entity.Student;
import com.example.Entity.CleanRequest;
import com.example.Entity.Feedback;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StudentTest {

    @Test
    public void testStudentCreation() {
        // Create a list of Feedback instances for testing
        List<Feedback> feedbacks = new ArrayList<>();
        Feedback feedback1 = new Feedback();
        Feedback feedback2 = new Feedback();
        feedbacks.add(feedback1);
        feedbacks.add(feedback2);

        // Create a list of CleanRequest instances for testing
        List<CleanRequest> cleanRequests = new ArrayList<>();
        CleanRequest request1 = new CleanRequest();
        CleanRequest request2 = new CleanRequest();
        cleanRequests.add(request1);
        cleanRequests.add(request2);

        // Create a Student instance
        Student student = new Student();
       
        student.setPassword("securePassword");
        student.setFloor(2);
        student.setHostel("A");
        student.setRoom("101");
        student.setFeedbacks(feedbacks);
        student.setRequest_id(cleanRequests);

        // Perform assertions to test the Student instance
        
        assertEquals("securePassword", student.getPassword());
        assertEquals(2, student.getFloor());
        assertEquals("A", student.getHostel());
        assertEquals("101", student.getRoom());
        assertEquals(feedbacks, student.getFeedbacks());
        assertEquals(cleanRequests, student.getRequest_id());
    }
}

