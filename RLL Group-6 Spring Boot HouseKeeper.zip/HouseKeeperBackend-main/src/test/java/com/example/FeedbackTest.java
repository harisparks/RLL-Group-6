package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.Entity.Student;
import com.example.Entity.CleanRequest;
import com.example.Entity.Feedback;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FeedbackTest {

    @Test
    public void testFeedbackCreation() {
        
        Student student = new Student();
        

        CleanRequest cleanRequest = new CleanRequest();

        
        Feedback feedback = new Feedback();
        feedback.setFeedback_id(1L);
        feedback.setStudent(student);
        feedback.setCleanRequest(cleanRequest);
        feedback.setFeedback("The cleaning service was excellent!");

       
        assertEquals(1L, feedback.getFeedback_id());
        assertEquals(student, feedback.getStudent());
        assertEquals(cleanRequest, feedback.getCleanRequest());
        assertEquals("The cleaning service was excellent!", feedback.getFeedback());
    }
}
